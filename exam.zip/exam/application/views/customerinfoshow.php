<table class="table table-hover">
    <tbody>
    	<tr>
        <th>Serial</th>
        <th>Customer Name</th>
        <th>Product Name</th>
        <th>Transection Type</th>
        <th>Product Price</th>
        <th>Date</th>
    	</tr>
    	<?php
    	$i=1;
    	$purchescustomerinfo=$this->db->from('customerpurchasedproduct')->where('customer_id',$customer_id)->get()->result();
    	//var_dump($purchescustomerinfo);
  		foreach ($purchescustomerinfo as $row) {
  		?>
  		<tr>
			<td><?=$i; ?></td>
            <td>
            	<?php
            	$customer=$this->db->from('customer')->where('id',$row->customer_id)->get()->row();
            	echo $customer->name;
            	?>
            </td>
            <td>
            	<?php
            	$pord=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            	echo $pord->name;
            	?>
            </td>
            <td>Purchased</td>
            <td><?=$pord->price; ?></td>
            <td><?=$row->created_at; ?></td>
		</tr>	
  		<?php $i++; } ?>

    	<?php
    	
    	$salescustomerinfo=$this->db->from('customersalesproduct')->where('customer_id',$customer_id)->get()->result();
    	
  		foreach ($salescustomerinfo as $row) {
  		?>
  		<tr>
			<td><?=$i; ?></td>
            <td>
            	<?php
            	$customer=$this->db->from('customer')->where('id',$row->customer_id)->get()->row();
            	echo $customer->name;
            	?>
            </td>
            <td>
            	<?php
            	$pord=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            	echo $pord->name;
            	?>
            </td>
            <td>Sales</td>
            <td><?=$pord->price; ?></td>
            <td><?=$row->created_at; ?></td>
		</tr>	
  		<?php $i++; } ?>


		
			 	   
	</tbody>

</table>   