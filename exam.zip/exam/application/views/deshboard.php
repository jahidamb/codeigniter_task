<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<br>
<div class="row">
            <br>
<div class="col-md-6">
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title">Total Product Purchased</h3>
        </div>
        <div class="panel-body">
        	<?php
        	$total=0;
	   		foreach ($purses->result() as $row){
	   		
            $products=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            $total+=$products->price;
            }
            echo $total;
	   		?>
                    
        </div>
        <div class="panel-footer">

        <table class="table table-hover">
    	<tbody>
    	<tr>
        <th>Serial</th>
        <th>Time</th>
        <th>Amount</th>
        
   		</tr>
   		<?php
   		$i=1;

   		foreach ($purses->result() as $row){
   		
   		?>
        <tr>
            <td><?=$i; ?></td>
            <td>
            	<?php $newDateFormat2 = date('F:Y', strtotime($row->created_at));
                 echo $newDateFormat2;
                 ?>
            </td>
            <td>
            	<?php
            	$pord=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            	echo $pord->price;
            	?>
            </td>   
        </tr>
        <?php $i++; } ?>

    
		</tbody>
		</table>


        </div>
    </div>
</div>
<div class="col-md-6">
<div class="panel panel-success">
        <div class="panel-heading">
            <h3 class="panel-title">Total Product Sales</h3>
        </div>
        <div class="panel-body">
        <?php
    	$Stotal=0;
   		foreach ($sales->result() as $row){
   		
        $products=$this->db->from('product')->where('id',$row->product_id)->get()->row();
        $Stotal+=$products->price;
        }
        echo $Stotal;
   		?>        
    	</div>
        <div class="panel-footer">

        <table class="table table-hover">
    <tbody>
    	<tr>
        <th>Serial</th>
        <th>Time</th>
        <th>Amount</th>
        
    	</tr>
        <?php
   		$i=1;

   		foreach ($sales->result() as $row){
   		
   		?>
        <tr>
            <td><?=$i; ?></td>
            <td>
            	<?php $newDateFormat2 = date('F:Y', strtotime($row->created_at));
                 echo $newDateFormat2;
                 ?>
            </td>
            <td>
            	<?php
            	$pord=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            	echo $pord->price;
            	?>
            </td>   
        </tr>
        <?php $i++; } ?>
    
</tbody></table>


        </div>
    </div>
</div>
        </div>
<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>