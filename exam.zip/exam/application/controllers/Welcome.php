<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

    public function index()
    {
        $data['main_content'] = "exam";
        $data['main_content'] = $this->load->view('exam', $data, TRUE);
        $this->load->view('master', $data);
    }

    

    public function shop()
    {
        $data['products'] = $this->Common->get_data('product');
        $data['customer'] = $this->Common->get_data('customer');
        $data['main_content'] = $this->load->view('shop', $data, TRUE);
        $this->load->view('master', $data);
    }

    public function store_shop(){
        $storeUpdate = array(
            'customer_id' =>$this->input->post('customer_id') , 
            'product_id' => $this->input->post('product_id'), 
        );
        if($this->input->post('type')=='1'){
            for ($i=0; $i < $this->input->post('quantity'); $i++) { 
                $this->Common->set_data('customersalesproduct',$storeUpdate);
            }
        }
        else{
            for ($i=0; $i < $this->input->post('quantity'); $i++) { 
                $this->Common->set_data('customerpurchasedproduct',$storeUpdate);
            }  
        }
        redirect('shop','refresh');  
    }


    public function dashboard(){

        $data['purses'] = $this->Common->get_data('customerpurchasedproduct');
        $data['sales'] = $this->Common->get_data('customersalesproduct');
        $data['main_content'] = $this->load->view('deshboard', $data, TRUE);
        $this->load->view('master', $data);
        
    }
    

    public function sale_report(){

    $data['salesreport'] = $this->Common->get_data('customersalesproduct');
    $data['main_content'] = $this->load->view('sales_report', $data, TRUE);
    $this->load->view('master', $data);


    }

    public function customer_info(){
        $data['customers'] = $this->Common->get_data('customer');
        $data['main_content'] = $this->load->view('custmomers_info', $data, TRUE);
        $this->load->view('master', $data);
    }

    public function customer_result(){

    $data['customer_id']=$this->input->post('customer');
    // var_dump($data);
    // exit();
    $this->load->view('customerinfoshow',$data);

    }


    
}
