<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<br>
<div class="row">
            <br>
<table class="table table-hover">
    <tbody>
    	<tr>
        <th>Serial</th>
        <th>Customer Name</th>
        <th>Product Name</th>
        <th>Transection Type</th>
        <th>Product Price</th>
        <th>Date</th>
    	</tr>
    	<?php
   		$i=1;

   		foreach ($salesreport->result() as $row){
   		
   		?>
        <tr>
            <td><?=$i; ?></td>
            <td>
            	<?php
            	$customer=$this->db->from('customer')->where('id',$row->customer_id)->get()->row();
            	echo $customer->name;
            	?>
            </td>
            <td>
            	<?php
            	$pord=$this->db->from('product')->where('id',$row->product_id)->get()->row();
            	echo $pord->name;
            	?>
            </td>
            <td>Sales</td>
            <td><?=$pord->price; ?></td>
            <td><?=$row->created_at; ?></td>
        </tr>
         <?php $i++; } ?>
    
</tbody>
</table>        

</div>

<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>