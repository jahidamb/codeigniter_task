<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/css/select2.min.css" rel="stylesheet" />
<br>
<div class="row">
<form method="POST" action="http://13.126.188.147/exam/Welcome/customer_result">
        <div class="box-body">

            <div class="col-md-4">
                <div class="form-group">
                    <label>Customer Name</label>  <br>
                    <select class="form-control" id="customer">
					<?php
					foreach ($customers->result() as $row){
					   		
					?>
                    <option value="<?=$row->id; ?>"><?=$row->name; ?></option>
                	<?php } ?>
                        
                    </select>
                </div>
            </div>
            <div class="col-md-4">
                <br>
                <button id="submit" type="submit" class="btn btn-primary">Submit</button>
            </div>
            <div class="col-md-4"></div>








        </div>
        <!-- /.box-body -->

        <div class="box-footer">
            
        </div>
    </form>


            <br>

	<div id="show"></div>
   

</div>

<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-beta.1/dist/js/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.js-example-basic-single').select2();
    });
</script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>



 <script>
    $(document).ready(function(){
        $("#submit").click(function(){
            //var year = $("#year").val();
            var customer = $("#customer").val();
            
          var dataString = 'customer='+ customer;
            
                $.ajax({
                    type: "POST",
                    url:'<?=base_url()?>welcome/customer_result',
                    data: dataString,
                   
                    cache: false,
                    success: function(response){
                        
                    $("#show").html(response);
                    }
                });
          
            return false;
        });
    });
</script>