<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
class Common extends CI_Model {
    
    public function set_data($table,$data){
        $this->db->trans_start();
        $this->db->insert($table, $data);
        $returnValue = $this->db->insert_id();
        $this->db->trans_complete();
        if ($this->db->trans_status() === FALSE)
        {
            return FALSE;
        }
        else
        {
            return $returnValue;
        }
    }

    public function get_data($table){
        $query= $this->db->get($table);
        if ( $this->db->affected_rows() > 0 ) {
            return $query;
        } else {
            return FALSE;
        }
    }

    // public function get_purses(){
    //     $this->db->from('customerpurchasedproduct');
    //     $this->db->join('product', 'customerpurchasedproduct.product_id = product.id', 'left');
    //     $query=$this->db->get();
    //     return $query->result(); 
    // }


    

}


